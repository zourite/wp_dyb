<h3>Lien HR-XML de votre CV</h3>
<div class="wrap">
<p> Veuillez insérer le lien HR-XML de votre CV dans la case ci dessous</p>
<form method="post" action=" admin.php?page=dyb-zourite">
<img src="<?php echo WP_PLUGIN_URL.'/'.basename(dirname(__FILE__))?>/img/hr-xml.png"/>
<p><input type="text" name="hr-xml"/> <input type="submit" value="Envoyer" name="submit"/></p>
</form>
</div>
