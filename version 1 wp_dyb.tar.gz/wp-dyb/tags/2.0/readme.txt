=== DoYouBuzz CV ===

Contributors: zourtie
Tags: resume, DoYouBuzz
Requires at least: 3.0
Tested up to: 3.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

DoYouBuzz CV allows you to display your CV DoYouBuzz on your Wordpress site.

== Description ==

<a href='http://www.doyoubuzz.com'>DoYouBuzz</a> is a company specializing in technology creation, diffusion and management of CV on the web.

This plugin allows to view your experience / skills in a sidebar or a page

== Installation ==

1. Download, install, and activate the plugin.

2. From your Wordpress Dashboard, go to WP_DYB and insert the HR-XML link of your CV.

== Usage ==

<strong>You can insert function in your template :</strong>

* <code>wp_dyb('contact')</code> Display Twitter, Viadeo, Linkedin link. 
* <code>wp_dyb('employment')</code> Display your experience.
* <code>wp_dyb('skill')</code> Display your Skill.
* <code>wp_dyb('intro')</code> Display the introduction of you CV.
* <code>wp_dyb('formation)</code> Display your schooling.

<strong>Three widgets are available :</strong>

* Statut DoYouBuzz - Display if you can de employed or not.
* Compétences DoYouBuzz - Display your SKill
* Experience DoYouBuzz - Dispaly your Experience


